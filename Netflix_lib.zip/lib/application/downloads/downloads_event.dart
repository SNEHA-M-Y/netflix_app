part of 'downloads_bloc.dart';

@freezed
class DownloadsEvent with _$DownloadsEvent {
  const factory DownloadsEvent.getDownloadsImage() = _GetDownloadsImage;
}
