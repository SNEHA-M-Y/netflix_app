import 'package:flutter/material.dart';
import 'package:netflix_app/core/constants.dart';

class MainCard extends StatelessWidget {
  const MainCard({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 10),
          width: 130,
          height: 250,
          decoration: BoxDecoration(
            color: Colors.red,
            borderRadius: kRadius10,
            image: const DecorationImage(
              fit: BoxFit.cover,
              image: NetworkImage(
                "https://image.tmdb.org/t/p/original/95p65Eb3meuWj8DhldOeIz3NLPF.jpg",
              ),
            ),
          ),
        ),
        kWidth,
      ],
    );
  }
}
