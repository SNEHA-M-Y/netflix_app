import 'package:flutter/material.dart';

const backgroundColor = Colors.black;
const kWhiteColor = Colors.white;
const kButtonColorBlue = Colors.blue;
const kButtonColorWhite = Colors.white;
const kBlackColor = Colors.black;
const kGreyColor = Colors.grey;
const KBlueColor = Colors.blue;
