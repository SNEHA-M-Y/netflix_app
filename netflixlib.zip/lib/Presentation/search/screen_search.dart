import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:netflix_app/core/colors/colors.dart';
import 'package:netflix_app/Presentation/search/widget/search_results.dart';

class ScreenSearch extends StatelessWidget {
  const ScreenSearch({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
        children: [
        CupertinoSearchTextField(backgroundColor:Colors.grey.withOpacity(0.5),
        prefixIcon:Icon(CupertinoIcons.search,color: Colors.grey,) ,
        suffixIcon: Icon(CupertinoIcons.xmark_circle_fill,color: Colors.grey,),
        style: TextStyle(color:kWhiteColor ),
        ),
       //Expanded(child: SearchIdleWidget())
        Expanded(child: SearchResultWidget())
      ],))
    );
  }
}